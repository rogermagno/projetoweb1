<html>
	<head>
		<title><?php echo (empty($this->title)) ? "Generic Title" : $this->title ?></title>
	</head>
	<body>

