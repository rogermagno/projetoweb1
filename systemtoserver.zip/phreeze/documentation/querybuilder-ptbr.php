<?php include_once '_header-ptbr.php' ?>

<h3 id="top">QueryBuilder</h3>

<h4>Arquivos e Vídeos Relacionados</h4>

<ul class="nobullets">
	<li><i class="icon-download"></i> <a href="assets/m2m-example.zip">App Exemplo Muitos-para-Muitos</a></li>
</ul>

<h4 id="overview">Overview</h4>

<p>Esta página estará pronta em breve. Documentação é um trabalho duro. Quer contribuir?  Pull requests serão bem aceitos!</p>

<?php include_once '_footer-ptbr.php' ?>
