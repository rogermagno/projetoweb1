<?php include_once '_header-ptbr.php' ?>

<h3 id="top">Controllers</h3>

<h4>Arquivos e Vídeos Relacionados</h4>

<ul class="nobullets">
	<li><i class="icon-play"></i> <a href="#video1Modal" data-toggle="modal">Vídeo de Treinamento Básico #2: Routes e Controllers</a></li>
</ul>

<div id="video1Modal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="video1Label" aria-hidden="true">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
		<h3 id="myModalLabel">Phreeze Training Video</h3>
	</div>
	<div class="modal-body">
		<iframe width="530" height="298" src="http://www.youtube.com/embed/p5pXlNqO1Tc" frameborder="0" allowfullscreen></iframe>
	</div>
	<div class="modal-footer">
		<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
	</div>
</div>

<h4 id="overview">Overview</h4>

<p>Esta página estará pronta em breve.  Documentação é um trabalho duro!  Quer contribuir?  Pull requests serão aceitos com prazer!</p>

<h4 id=""></h4>

<?php include_once '_footer-ptbr.php' ?>
