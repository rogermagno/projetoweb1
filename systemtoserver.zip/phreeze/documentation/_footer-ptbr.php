
				<hr>

				<footer>
					<div>Phreeze &copy; 2015 <a href="http://verysimple.com/">verysimple.com</a></div>
					<div>Documentação traduzida para o Português do Brasil por <a href="http://calheira.com/">Bruno Calheira</a></div>
					<div>Licenciado para uso pessoal e comercial sob a  <a href="http://www.gnu.org/licenses/lgpl.php">LGPL</a></div>
				</footer>

			</div> <!-- /container -->

			<script type="text/javascript" src="scripts/jquery-1.7.2.min.js"></script>
			<script type="text/javascript" src="scripts/prettify.js"></script>

			<!-- Le javascript
			================================================== -->
			<!-- Placed at the end of the document so the pages load faster -->
			<script type="text/javascript" src="../builder/bootstrap/js/bootstrap.min.js"></script>

			<script type="text/javascript">
				$(document).ready(function() {
					
					$('.popover-icon').popover();
					
				    // make code pretty
				    window.prettyPrint && prettyPrint()
					
				});
			</script>
	</body>
</html>