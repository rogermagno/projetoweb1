# PHREEZE TEST RUNNER
# This is a test runner script for PHREEZE
# See README for setup instructions
#
phpunit ./Tests/AllTests