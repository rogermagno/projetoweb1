<?php /* Smarty version Smarty-3.1.18, created on 2017-04-26 03:31:51
         compiled from "C:\xampp\htdocs\phreeze\builder\code\phreeze.backbone\styles\style.css" */ ?>
<?php /*%%SmartyHeaderCode:819758fff8876c3695-55728350%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ac89745cdfb34c97fec0521c479b3478c34e361a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\phreeze\\builder\\code\\phreeze.backbone\\styles\\style.css',
      1 => 1457898384,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '819758fff8876c3695-55728350',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_58fff8876cb3a8_86119622',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58fff8876cb3a8_86119622')) {function content_58fff8876cb3a8_86119622($_smarty_tpl) {?>/*!
 * application style overrides and customizations
 */

/* note that this gets overridden by bootstrap-responsive.min.css when screen size changes */
body {
	padding-top: 60px;
	padding-bottom: 40px;
}

h1 {
	margin-bottom: 8px;
}

hr {
	margin: 10px 0px 10px 0px;
}

p.buttonContainer {

}

table.collection tr:hover {
    cursor: pointer;
}

table.collection th:hover {
    cursor: pointer;
    opacity: 0.5;
}

.date-picker input
{
	width: 80px;
}

.date-picker i
{
	color: #999;
	margin-top: 2px;
	margin-left: -1px;
}

.bootstrap-timepicker-component input
{
	width: 70px;
}

.bootstrap-timepicker-component i
{
	color: #999;
	margin-top: 3px;
	margin-left: 0px;
}

.searchContainer input, searchContainer button
{
	margin-top: 8px;
}

.searchContainer input
{
	margin-top: 8px;
}

/* search filter button */
.input-append button.add-on {
    height: inherit !important;
    color: #999999;
    padding-left: 10px;
    padding-right: 10px;
    margin-top: 8px;
}

span.loader {
	margin: 0px;
	display: inline-block;
	width: 150px;
}

span.loader .bar {
	display: inline-block;
	width: 100%;
	height: 30px;
}

/* form controls */
span.help-inline {
	font-size: .9em;
	font-style: italic;
	padding-top: 5px;
	color: #999;
}

/* fixes spacing glitch with combo-box followed by an empty inline help */
span.help-inline:empty {
	display: none;
}
<?php }} ?>
