<?php /* Smarty version Smarty-3.1.18, created on 2017-04-26 03:31:51
         compiled from "C:\xampp\htdocs\phreeze\builder\code\phreeze.savant\templates\DefaultError404.tpl.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3056858fff8877118b2-88544731%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f11220353b3cbd84b4cb362b1434cd572aad0072' => 
    array (
      0 => 'C:\\xampp\\htdocs\\phreeze\\builder\\code\\phreeze.savant\\templates\\DefaultError404.tpl.tpl',
      1 => 1457898384,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3056858fff8877118b2-88544731',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'appname' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_58fff887715732_78409022',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58fff887715732_78409022')) {function content_58fff887715732_78409022($_smarty_tpl) {?><<?php ?>?php
	$this->assign('title','<?php echo $_smarty_tpl->tpl_vars['appname']->value;?>
 | File Not Found');
	$this->assign('nav','home');

	$this->display('_Header.tpl.php');
?<?php ?>>

<div class="container">

	<h1>Oh Snap!</h1>

	<!-- this is used by app.js for scraping -->
	<!-- ERROR The page you requested was not found /ERROR -->

	<p>The page you requested was not found.  Please check that you typed the URL correctly.</p>

</div> <!-- /container -->

<<?php ?>?php
	$this->display('_Footer.tpl.php');
?<?php ?>><?php }} ?>
