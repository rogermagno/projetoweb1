<?php /* Smarty version Smarty-3.1.18, created on 2017-04-26 03:31:51
         compiled from "C:\xampp\htdocs\phreeze\builder\code\phreeze.backbone\libs\Controller\DefaultController.php.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2802258fff887321ac9-60378135%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4036d45606bf93050b07ac717d7a82150df53854' => 
    array (
      0 => 'C:\\xampp\\htdocs\\phreeze\\builder\\code\\phreeze.backbone\\libs\\Controller\\DefaultController.php.tpl',
      1 => 1457898384,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2802258fff887321ac9-60378135',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'connection' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_58fff887383556_68699649',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58fff887383556_68699649')) {function content_58fff887383556_68699649($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_studlycaps')) include 'C:\\xampp\\htdocs\\phreeze\\libs\\smarty\\plugins\\modifier.studlycaps.php';
?><<?php ?>?php
/** @package <?php echo smarty_modifier_studlycaps($_smarty_tpl->tpl_vars['connection']->value->DBName);?>
::Controller */

/** import supporting libraries */
require_once("AppBaseController.php");

/**
 * DefaultController is the entry point to the application
 *
 * @package <?php echo smarty_modifier_studlycaps($_smarty_tpl->tpl_vars['connection']->value->DBName);?>
::Controller
 * @author ClassBuilder
 * @version 1.0
 */
class DefaultController extends AppBaseController
{

	/**
	 * Override here for any controller-specific functionality
	 */
	protected function Init()
	{
		parent::Init();

		// TODO: add controller-wide bootstrap code
		
		// TODO: if authentiation is required for this entire controller, for example:
		// $this->RequirePermission(ExampleUser::$PERMISSION_USER,'SecureExample.LoginForm');
	}

	/**
	 * Display the home page for the application
	 */
	public function Home()
	{
		$this->Render();
	}

	/**
	 * Displayed when an invalid route is specified
	 */
	public function Error404()
	{
		$this->Render();
	}

	/**
	 * Display a fatal error message
	 */
	public function ErrorFatal()
	{
		$this->Render();
	}

	public function ErrorApi404()
	{
		$this->RenderErrorJSON('An unknown API endpoint was requested.');
	}

}
?<?php ?>><?php }} ?>
