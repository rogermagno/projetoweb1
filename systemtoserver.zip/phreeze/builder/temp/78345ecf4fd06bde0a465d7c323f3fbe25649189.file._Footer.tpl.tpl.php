<?php /* Smarty version Smarty-3.1.18, created on 2017-04-26 03:31:51
         compiled from "C:\xampp\htdocs\phreeze\builder\code\phreeze.savant\templates\_Footer.tpl.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1498758fff887701ea9-64724466%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '78345ecf4fd06bde0a465d7c323f3fbe25649189' => 
    array (
      0 => 'C:\\xampp\\htdocs\\phreeze\\builder\\code\\phreeze.savant\\templates\\_Footer.tpl.tpl',
      1 => 1457898384,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1498758fff887701ea9-64724466',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'appname' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_58fff887705d26_18931920',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58fff887705d26_18931920')) {function content_58fff887705d26_18931920($_smarty_tpl) {?>	<!-- footer -->
	<div class="container">
		<hr>
		<footer>
			<p class="muted"><small>&copy; <<?php ?>?php echo date('Y'); ?<?php ?>> <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['appname']->value, ENT_QUOTES, 'UTF-8', true);?>
</small></p>
		</footer>
	</div>
	</body>
</html><?php }} ?>
