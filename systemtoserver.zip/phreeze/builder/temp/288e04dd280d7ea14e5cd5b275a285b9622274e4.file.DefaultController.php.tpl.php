<?php /* Smarty version Smarty-3.1.18, created on 2016-12-26 17:42:41
         compiled from "C:\MAMP\htdocs\phreeze\builder\code\phreeze.backbone\libs\Controller\DefaultController.php.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1225958615691b290e9-25553234%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '288e04dd280d7ea14e5cd5b275a285b9622274e4' => 
    array (
      0 => 'C:\\MAMP\\htdocs\\phreeze\\builder\\code\\phreeze.backbone\\libs\\Controller\\DefaultController.php.tpl',
      1 => 1457912785,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1225958615691b290e9-25553234',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'connection' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_58615691b65fe3_39947665',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58615691b65fe3_39947665')) {function content_58615691b65fe3_39947665($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_studlycaps')) include 'C:\\MAMP\\htdocs\\phreeze\\libs\\smarty\\plugins\\modifier.studlycaps.php';
?><<?php ?>?php
/** @package <?php echo smarty_modifier_studlycaps($_smarty_tpl->tpl_vars['connection']->value->DBName);?>
::Controller */

/** import supporting libraries */
require_once("AppBaseController.php");

/**
 * DefaultController is the entry point to the application
 *
 * @package <?php echo smarty_modifier_studlycaps($_smarty_tpl->tpl_vars['connection']->value->DBName);?>
::Controller
 * @author ClassBuilder
 * @version 1.0
 */
class DefaultController extends AppBaseController
{

	/**
	 * Override here for any controller-specific functionality
	 */
	protected function Init()
	{
		parent::Init();

		// TODO: add controller-wide bootstrap code
		
		// TODO: if authentiation is required for this entire controller, for example:
		// $this->RequirePermission(ExampleUser::$PERMISSION_USER,'SecureExample.LoginForm');
	}

	/**
	 * Display the home page for the application
	 */
	public function Home()
	{
		$this->Render();
	}

	/**
	 * Displayed when an invalid route is specified
	 */
	public function Error404()
	{
		$this->Render();
	}

	/**
	 * Display a fatal error message
	 */
	public function ErrorFatal()
	{
		$this->Render();
	}

	public function ErrorApi404()
	{
		$this->RenderErrorJSON('An unknown API endpoint was requested.');
	}

}
?<?php ?>><?php }} ?>
