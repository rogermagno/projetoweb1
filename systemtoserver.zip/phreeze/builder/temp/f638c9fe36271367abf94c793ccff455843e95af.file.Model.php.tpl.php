<?php /* Smarty version Smarty-3.1.18, created on 2017-04-26 03:31:51
         compiled from "C:\xampp\htdocs\phreeze\builder\code\phreeze.php\libs\Model\Model.php.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1338958fff8874a0813-46021912%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f638c9fe36271367abf94c793ccff455843e95af' => 
    array (
      0 => 'C:\\xampp\\htdocs\\phreeze\\builder\\code\\phreeze.php\\libs\\Model\\Model.php.tpl',
      1 => 1457898384,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1338958fff8874a0813-46021912',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'connection' => 0,
    'singular' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_58fff8874b40a2_61978538',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58fff8874b40a2_61978538')) {function content_58fff8874b40a2_61978538($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_studlycaps')) include 'C:\\xampp\\htdocs\\phreeze\\libs\\smarty\\plugins\\modifier.studlycaps.php';
?><<?php ?>?php
/** @package    <?php echo smarty_modifier_studlycaps($_smarty_tpl->tpl_vars['connection']->value->DBName);?>
::Model */

/** import supporting libraries */
require_once("DAO/<?php echo $_smarty_tpl->tpl_vars['singular']->value;?>
DAO.php");
require_once("<?php echo $_smarty_tpl->tpl_vars['singular']->value;?>
Criteria.php");

/**
 * The <?php echo $_smarty_tpl->tpl_vars['singular']->value;?>
 class extends <?php echo $_smarty_tpl->tpl_vars['singular']->value;?>
DAO which provides the access
 * to the datastore.
 *
 * @package <?php echo smarty_modifier_studlycaps($_smarty_tpl->tpl_vars['connection']->value->DBName);?>
::Model
 * @author ClassBuilder
 * @version 1.0
 */
class <?php echo $_smarty_tpl->tpl_vars['singular']->value;?>
 extends <?php echo $_smarty_tpl->tpl_vars['singular']->value;?>
DAO
{

	/**
	 * Override default validation
	 * @see Phreezable::Validate()
	 */
	public function Validate()
	{
		// example of custom validation
		// $this->ResetValidationErrors();
		// $errors = $this->GetValidationErrors();
		// if ($error == true) $this->AddValidationError('FieldName', 'Error Information');
		// return !$this->HasValidationErrors();

		return parent::Validate();
	}

	/**
	 * @see Phreezable::OnSave()
	 */
	public function OnSave($insert)
	{
		// the controller create/update methods validate before saving.  this will be a
		// redundant validation check, however it will ensure data integrity at the model
		// level based on validation rules.  comment this line out if this is not desired
		if (!$this->Validate()) throw new Exception('Unable to Save <?php echo $_smarty_tpl->tpl_vars['singular']->value;?>
: ' .  implode(', ', $this->GetValidationErrors()));

		// OnSave must return true or Phreeze will cancel the save operation
		return true;
	}

}

?<?php ?>>
<?php }} ?>
