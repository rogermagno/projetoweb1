<?php /* Smarty version Smarty-3.1.18, created on 2016-12-26 17:42:41
         compiled from "C:\MAMP\htdocs\phreeze\builder\code\phreeze.savant\templates\DefaultError404.tpl.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2305358615691e7e2e8-00071960%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fceefaa26caf1f6dcabd9830375410b27a8711e3' => 
    array (
      0 => 'C:\\MAMP\\htdocs\\phreeze\\builder\\code\\phreeze.savant\\templates\\DefaultError404.tpl.tpl',
      1 => 1457912785,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2305358615691e7e2e8-00071960',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'appname' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_58615691e7e2e6_28529721',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58615691e7e2e6_28529721')) {function content_58615691e7e2e6_28529721($_smarty_tpl) {?><<?php ?>?php
	$this->assign('title','<?php echo $_smarty_tpl->tpl_vars['appname']->value;?>
 | File Not Found');
	$this->assign('nav','home');

	$this->display('_Header.tpl.php');
?<?php ?>>

<div class="container">

	<h1>Oh Snap!</h1>

	<!-- this is used by app.js for scraping -->
	<!-- ERROR The page you requested was not found /ERROR -->

	<p>The page you requested was not found.  Please check that you typed the URL correctly.</p>

</div> <!-- /container -->

<<?php ?>?php
	$this->display('_Footer.tpl.php');
?<?php ?>><?php }} ?>
