<?php /* Smarty version Smarty-3.1.18, created on 2017-04-26 03:31:51
         compiled from "C:\xampp\htdocs\phreeze\builder\code\phreeze.savant\templates\DefaultErrorFatal.tpl.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1420958fff8877212b8-22852525%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '00263e4885e45f6f9fad111491554403b291e6b6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\phreeze\\builder\\code\\phreeze.savant\\templates\\DefaultErrorFatal.tpl.tpl',
      1 => 1457898384,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1420958fff8877212b8-22852525',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'appname' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_58fff887725139_63649040',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_58fff887725139_63649040')) {function content_58fff887725139_63649040($_smarty_tpl) {?><<?php ?>?php
	$this->assign('title','<?php echo $_smarty_tpl->tpl_vars['appname']->value;?>
');
	$this->assign('nav','home');

	$this->display('_Header.tpl.php');
?<?php ?>>

<div class="container">

	<h1>Oh Snap!</h1>

	<!-- this is used by app.js for scraping -->
	<!-- ERROR <<?php ?>?php $this->eprint($this->message); ?<?php ?>> /ERROR -->

	<h3 onclick="$('#stacktrace').show('slow');" class="well" style="cursor: pointer;"><<?php ?>?php $this->eprint($this->message); ?<?php ?>></h3>

	<p>You may want to try returning to the the previous page and verifying that
	all fields have been filled out correctly.</p>

	<p>If you continue to experience this error please contact support.</p>

	<div id="stacktrace" class="well hide">
		<p style="font-weight: bold;">Stack Trace:</p>
		<<?php ?>?php if ($this->stacktrace) { ?<?php ?>>
			<p style="white-space: nowrap; overflow: auto; padding-bottom: 15px; font-family: courier new, courier; font-size: 8pt;"><pre><<?php ?>?php $this->eprint($this->stacktrace); ?<?php ?>></pre></p>
		<<?php ?>?php } ?<?php ?>>
	</div>

</div> <!-- /container -->

<<?php ?>?php
	$this->display('_Footer.tpl.php');
?<?php ?>><?php }} ?>
