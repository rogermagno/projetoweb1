	<!-- footer -->
	<div class="container">
		<hr>
		<footer>
			<p class="muted"><small>&copy; <?php echo date('Y'); ?> SYSTEMTOSERVER</small></p>
		</footer>
	</div>
	</body>
</html>