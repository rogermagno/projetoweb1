<?php
	$this->assign('title','SYSTEMTOSERVER Secure Example');
	$this->assign('nav','secureexample');

	$this->display('_Header.tpl.php');
?>
<center>
<div class="container">

	<?php if ($this->feedback) { ?>
		<div class="alert alert-error">
			<button type="button" class="close" data-dismiss="alert">×</button>
			<?php $this->eprint($this->feedback); ?>
		</div>
	<?php } ?>
	
	
	
	<?php if ($this->page == 'login') { ?>
	
	
	
		<form class="well" method="post" action="login">
			<fieldset>
			<legend>Entrar no Sistema</legend>
				<div class="control-group">
				<input id="username" name="username" type="text" placeholder="Nome..." />
				</div>
				<div class="control-group">
				<input id="password" name="password" type="password" placeholder="Senha..." />
				</div>
				<div class="control-group">
				<button type="submit" class="btn btn-primary">Entrar</button>
												
				<button type="logout" class="btn btn-primary">Sair</button>
				<button type="reset" class="btn btn-primary">Limpar</button>
				
				
				</div>
			</fieldset>
		</form>
	
	<?php } else { ?>
	
		
	<?php } ?>

</div> <!-- /container -->

<?php
	$this->display('_Footer.tpl.php');
?>