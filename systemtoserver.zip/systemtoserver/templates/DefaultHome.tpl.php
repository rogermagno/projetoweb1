<?php
	$this->assign('title','SYSTEMTOSERVER | Home');
	$this->assign('nav','home');

	$this->display('_Header.tpl.php');
?>

	

	<div class="container">
		
		<div class="row">
			<div class="span3">
				<h2><i class="icon-cogs "></i> Chamados</h2>
				 <p>Realize o cadastro de seus chamados</p>
				<p><a class="btn" href="./chamados">Crie um chamado</a></p>
			</div>
			<div class="span3">
				<h2><i class="icon-th"></i> Servidores</h2>
				 <p>Cadastre Seus Servidores</p>
				<p><a class="btn" href="./servidors">Meus Servidores</a></p>
		 	</div>
			<div class="span3">
				<h2><i class="icon-th"></i> Maquinas</h2>
				<p>Gerencie as Maquinas de sua rede</p>
				<p><a class="btn" href="./maquinas">Minhas Maquinas</a></p>
			</div>
			<div class="span3">
				<h2><i class="icon-th"></i>Rede</h2>
				<p>
				Cadastre seus Switches e Roteadores
				</p>
				<p><a class="btn" href="./concentradoreses">Equipamentos</a></p>
			</div>
			<div class="span3">
				<h2><i class="icon-cogs "></i> Administração</h2>
				<p>
				solicitar nova senha
				</p>
				<p><a class="btn" href="http://127.0.0.1/systemtoserver/login/cadastro.php">Esqueci minha senha</a></p>
				
				
			</div>

		
	</div>

		</div>

	</div> 

<?php
	$this->display('_Footer.tpl.php');
?>