<?php

require_once("verysimple/Phreeze/Reporter.php");


class ChamadoReporter extends Reporter
{

	
	public $CustomFieldExample;

	public $Id;
	public $Nome;
	public $Telefone;
	public $Local;
	public $Status;
	public $Obs;

	
	static function GetCustomQuery($criteria)
	{
		$sql = "select
			'custom value here...' as CustomFieldExample
			,`chamado`.`c_id` as Id
			,`chamado`.`c_nome` as Nome
			,`chamado`.`c_telefone` as Telefone
			,`chamado`.`c_local` as Local
			,`chamado`.`c_status` as Status
			,`chamado`.`c_obs` as Obs
		from `chamado`";

		$sql .= $criteria->GetWhere();
		$sql .= $criteria->GetOrder();

		return $sql;
	}
	
	static function GetCustomCountQuery($criteria)
	{
		$sql = "select count(1) as counter from `chamado`";

		$sql .= $criteria->GetWhere();

		return $sql;
	}
}

?>