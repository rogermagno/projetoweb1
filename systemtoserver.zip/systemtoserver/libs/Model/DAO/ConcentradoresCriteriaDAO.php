<?php
/** @package    Systemtoserver::Model::DAO */

/** import supporting libraries */
require_once("verysimple/Phreeze/Criteria.php");

/**
 * ConcentradoresCriteria allows custom querying for the Concentradores object.
 *
 * WARNING: THIS IS AN AUTO-GENERATED FILE
 *
 * This file should generally not be edited by hand except in special circumstances.
 * Add any custom business logic to the ModelCriteria class which is extended from this class.
 * Leaving this file alone will allow easy re-generation of all DAOs in the event of schema changes
 *
 * @inheritdocs
 * @package Systemtoserver::Model::DAO
 * @author ClassBuilder
 * @version 1.0
 */
class ConcentradoresCriteriaDAO extends Criteria
{

	public $Id_Equals;
	public $Id_NotEquals;
	public $Id_IsLike;
	public $Id_IsNotLike;
	public $Id_BeginsWith;
	public $Id_EndsWith;
	public $Id_GreaterThan;
	public $Id_GreaterThanOrEqual;
	public $Id_LessThan;
	public $Id_LessThanOrEqual;
	public $Id_In;
	public $Id_IsNotEmpty;
	public $Id_IsEmpty;
	public $Id_BitwiseOr;
	public $Id_BitwiseAnd;
	public $Nome_Equals;
	public $Nome_NotEquals;
	public $Nome_IsLike;
	public $Nome_IsNotLike;
	public $Nome_BeginsWith;
	public $Nome_EndsWith;
	public $Nome_GreaterThan;
	public $Nome_GreaterThanOrEqual;
	public $Nome_LessThan;
	public $Nome_LessThanOrEqual;
	public $Nome_In;
	public $Nome_IsNotEmpty;
	public $Nome_IsEmpty;
	public $Nome_BitwiseOr;
	public $Nome_BitwiseAnd;
	public $Ip_Equals;
	public $Ip_NotEquals;
	public $Ip_IsLike;
	public $Ip_IsNotLike;
	public $Ip_BeginsWith;
	public $Ip_EndsWith;
	public $Ip_GreaterThan;
	public $Ip_GreaterThanOrEqual;
	public $Ip_LessThan;
	public $Ip_LessThanOrEqual;
	public $Ip_In;
	public $Ip_IsNotEmpty;
	public $Ip_IsEmpty;
	public $Ip_BitwiseOr;
	public $Ip_BitwiseAnd;
	public $Usuario_Equals;
	public $Usuario_NotEquals;
	public $Usuario_IsLike;
	public $Usuario_IsNotLike;
	public $Usuario_BeginsWith;
	public $Usuario_EndsWith;
	public $Usuario_GreaterThan;
	public $Usuario_GreaterThanOrEqual;
	public $Usuario_LessThan;
	public $Usuario_LessThanOrEqual;
	public $Usuario_In;
	public $Usuario_IsNotEmpty;
	public $Usuario_IsEmpty;
	public $Usuario_BitwiseOr;
	public $Usuario_BitwiseAnd;
	public $So_Equals;
	public $So_NotEquals;
	public $So_IsLike;
	public $So_IsNotLike;
	public $So_BeginsWith;
	public $So_EndsWith;
	public $So_GreaterThan;
	public $So_GreaterThanOrEqual;
	public $So_LessThan;
	public $So_LessThanOrEqual;
	public $So_In;
	public $So_IsNotEmpty;
	public $So_IsEmpty;
	public $So_BitwiseOr;
	public $So_BitwiseAnd;
	public $Tipo_Equals;
	public $Tipo_NotEquals;
	public $Tipo_IsLike;
	public $Tipo_IsNotLike;
	public $Tipo_BeginsWith;
	public $Tipo_EndsWith;
	public $Tipo_GreaterThan;
	public $Tipo_GreaterThanOrEqual;
	public $Tipo_LessThan;
	public $Tipo_LessThanOrEqual;
	public $Tipo_In;
	public $Tipo_IsNotEmpty;
	public $Tipo_IsEmpty;
	public $Tipo_BitwiseOr;
	public $Tipo_BitwiseAnd;
	public $Senha_Equals;
	public $Senha_NotEquals;
	public $Senha_IsLike;
	public $Senha_IsNotLike;
	public $Senha_BeginsWith;
	public $Senha_EndsWith;
	public $Senha_GreaterThan;
	public $Senha_GreaterThanOrEqual;
	public $Senha_LessThan;
	public $Senha_LessThanOrEqual;
	public $Senha_In;
	public $Senha_IsNotEmpty;
	public $Senha_IsEmpty;
	public $Senha_BitwiseOr;
	public $Senha_BitwiseAnd;

}

?>