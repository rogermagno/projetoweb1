-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 06-Jun-2017 às 00:49
-- Versão do servidor: 10.1.21-MariaDB
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `systemtoserver`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `concentradores`
--

CREATE TABLE `concentradores` (
  `t_id` int(10) UNSIGNED NOT NULL,
  `t_nome` varchar(45) DEFAULT NULL,
  `t_ip` varchar(45) DEFAULT NULL,
  `t_usuario` varchar(45) DEFAULT NULL,
  `t_so` varchar(45) DEFAULT NULL,
  `t_tipo` varchar(45) DEFAULT NULL,
  `t_senha` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `concentradores`
--

INSERT INTO `concentradores` (`t_id`, `t_nome`, `t_ip`, `t_usuario`, `t_so`, `t_tipo`, `t_senha`) VALUES
(3, 'switch recepção', '192.168.7.127', 'root', 'Cisco 2.0', 'catalyst 2960 G', 'B3t3rr@b@'),
(4, 'roteador sala de reuniões', '192.168.0.254', 'admin', 'zyxel', 'wireless + 4rj45', 'passwd'),
(5, 'switch 5 andar', '10.206.144.3', 'root', 'padrao', 'cisco catalist 2960', 'xsmopwefrwergf');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `concentradores`
--
ALTER TABLE `concentradores`
  ADD PRIMARY KEY (`t_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `concentradores`
--
ALTER TABLE `concentradores`
  MODIFY `t_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
