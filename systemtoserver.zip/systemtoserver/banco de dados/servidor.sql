-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 06-Jun-2017 às 00:49
-- Versão do servidor: 10.1.21-MariaDB
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `systemtoserver`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `servidor`
--

CREATE TABLE `servidor` (
  `c_id` int(10) UNSIGNED NOT NULL,
  `c_nome` varchar(45) DEFAULT NULL,
  `c_ip` varchar(45) DEFAULT NULL,
  `c_usuario` varchar(45) DEFAULT NULL,
  `c_so` varchar(45) DEFAULT NULL,
  `c_tipo` varchar(45) DEFAULT NULL,
  `c_senha` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `servidor`
--

INSERT INTO `servidor` (`c_id`, `c_nome`, `c_ip`, `c_usuario`, `c_so`, `c_tipo`, `c_senha`) VALUES
(1, 'prontuário eletronico', '192.168.1.56', 'administrador', 'windows server', '64 bit', '12qwaszx'),
(2, 'Marcação Recepção', '192.168.7.10', 'administrador', 'windows server 2004', '64', '!@QWASZX'),
(3, 'proxy', '10.206.144.8', 'administrador', 'windows server 2004', '32', 'dcd987!#@$man'),
(4, 'complab', '10.206.144.90', 'administrador', 'windows server 2008', '64', 'mir@bol@nte2017');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `servidor`
--
ALTER TABLE `servidor`
  ADD PRIMARY KEY (`c_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
