-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 06-Jun-2017 às 00:48
-- Versão do servidor: 10.1.21-MariaDB
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `systemtoserver`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `chamado`
--

CREATE TABLE `chamado` (
  `c_id` int(10) UNSIGNED NOT NULL,
  `c_nome` varchar(45) DEFAULT NULL,
  `c_telefone` varchar(45) DEFAULT NULL,
  `c_local` varchar(45) DEFAULT NULL,
  `c_status` varchar(45) DEFAULT NULL,
  `c_obs` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `chamado`
--

INSERT INTO `chamado` (`c_id`, `c_nome`, `c_telefone`, `c_local`, `c_status`, `c_obs`) VALUES
(3, 'Flavia', '24182435', 'divisão de pessoal', 'Aberto', 'troca de teclado'),
(4, 'Mariana', '28781122', 'divisao de estatistica', 'Aberto', 'solicita troca de mouse'),
(5, 'roger', '28981234', 'CPD', 'fechado', 'substituição de switch'),
(6, 'giulia', '23411234', 'RH', 'Aberto', 'Sistema de cadastro não funciona'),
(7, 'ana clara', '23459876', 'divisão de telemática', 'Fechado', 'problema com rede'),
(8, 'marcia', '25663342', 'call center', 'Fechado', 'configuração de impressora'),
(9, 'lyssandra', '25768798', 'recepção', 'fechado', 'Sistema de cadastro não funciona'),
(10, 'maicon', '23454356', 'administrativo', 'fechado', 'troca de mouse'),
(11, 'aline', '23459876', 'laboratório c', 'Aberto', 'Maquina 5, não liga'),
(12, 'roberta', '134555666', 'fgfgfgg', 'aberto', 'gdgdgdgdg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `concentradores`
--

CREATE TABLE `concentradores` (
  `t_id` int(10) UNSIGNED NOT NULL,
  `t_nome` varchar(45) DEFAULT NULL,
  `t_ip` varchar(45) DEFAULT NULL,
  `t_usuario` varchar(45) DEFAULT NULL,
  `t_so` varchar(45) DEFAULT NULL,
  `t_tipo` varchar(45) DEFAULT NULL,
  `t_senha` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `concentradores`
--

INSERT INTO `concentradores` (`t_id`, `t_nome`, `t_ip`, `t_usuario`, `t_so`, `t_tipo`, `t_senha`) VALUES
(3, 'switch recepção', '192.168.7.127', 'root', 'Cisco 2.0', 'catalyst 2960 G', 'B3t3rr@b@'),
(4, 'roteador sala de reuniões', '192.168.0.254', 'admin', 'zyxel', 'wireless + 4rj45', 'passwd'),
(5, 'switch 5 andar', '10.206.144.3', 'root', 'padrao', 'cisco catalist 2960', 'xsmopwefrwergf');

-- --------------------------------------------------------

--
-- Estrutura da tabela `impressora`
--

CREATE TABLE `impressora` (
  `i_id` int(10) UNSIGNED NOT NULL,
  `i_nome` varchar(45) DEFAULT NULL,
  `i_ip` varchar(45) DEFAULT NULL,
  `i_usuario` varchar(45) DEFAULT NULL,
  `i_local` varchar(45) DEFAULT NULL,
  `i_registro` varchar(45) DEFAULT NULL,
  `i_senha` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `impressora`
--

INSERT INTO `impressora` (`i_id`, `i_nome`, `i_ip`, `i_usuario`, `i_local`, `i_registro`, `i_senha`) VALUES
(3, 'Okidata 491', '192.168.7.200', 'Administrator', 'divisão pessoal', '1508123i874', 'aaaaaa'),
(4, 'hp3136', 'Local', 'administrador', 'diretor Administrativo', '142637485', 'não possui');

-- --------------------------------------------------------

--
-- Estrutura da tabela `maquina`
--

CREATE TABLE `maquina` (
  `m_id` int(10) UNSIGNED NOT NULL,
  `m_nome` varchar(45) DEFAULT NULL,
  `m_ip` varchar(45) DEFAULT NULL,
  `m_usuario` varchar(45) DEFAULT NULL,
  `m_so` varchar(45) DEFAULT NULL,
  `m_tipo` enum('x86','x64','') DEFAULT NULL,
  `m_senha` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `maquina`
--

INSERT INTO `maquina` (`m_id`, `m_nome`, `m_ip`, `m_usuario`, `m_so`, `m_tipo`, `m_senha`) VALUES
(1, 'webcmam', '10.206.160.90', 'cmam', 'linux', 'x86', 'cmam@!'),
(2, 'PIN WEB', '192.168.7.126', 'root', 'SUSE', 'x64', '123456'),
(3, 'roger', '192.168.7.10', 'administrador', 'windows 7', 'x86', '12qwaszx');

-- --------------------------------------------------------

--
-- Estrutura da tabela `servidor`
--

CREATE TABLE `servidor` (
  `c_id` int(10) UNSIGNED NOT NULL,
  `c_nome` varchar(45) DEFAULT NULL,
  `c_ip` varchar(45) DEFAULT NULL,
  `c_usuario` varchar(45) DEFAULT NULL,
  `c_so` varchar(45) DEFAULT NULL,
  `c_tipo` varchar(45) DEFAULT NULL,
  `c_senha` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `servidor`
--

INSERT INTO `servidor` (`c_id`, `c_nome`, `c_ip`, `c_usuario`, `c_so`, `c_tipo`, `c_senha`) VALUES
(1, 'prontuário eletronico', '192.168.1.56', 'administrador', 'windows server', '64 bit', '12qwaszx'),
(2, 'Marcação Recepção', '192.168.7.10', 'administrador', 'windows server 2004', '64', '!@QWASZX'),
(3, 'proxy', '10.206.144.8', 'administrador', 'windows server 2004', '32', 'dcd987!#@$man'),
(4, 'complab', '10.206.144.90', 'administrador', 'windows server 2008', '64', 'mir@bol@nte2017');

-- --------------------------------------------------------

--
-- Estrutura da tabela `switch`
--

CREATE TABLE `switch` (
  `s_id` int(10) UNSIGNED NOT NULL,
  `s_modelo` varchar(45) DEFAULT NULL,
  `s_ip` varchar(45) DEFAULT NULL,
  `s_usuario` varchar(45) DEFAULT NULL,
  `s_local` varchar(45) DEFAULT NULL,
  `s_tipo` varchar(45) DEFAULT NULL,
  `s_senha` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chamado`
--
ALTER TABLE `chamado`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `concentradores`
--
ALTER TABLE `concentradores`
  ADD PRIMARY KEY (`t_id`);

--
-- Indexes for table `impressora`
--
ALTER TABLE `impressora`
  ADD PRIMARY KEY (`i_id`);

--
-- Indexes for table `maquina`
--
ALTER TABLE `maquina`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `servidor`
--
ALTER TABLE `servidor`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `switch`
--
ALTER TABLE `switch`
  ADD PRIMARY KEY (`s_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chamado`
--
ALTER TABLE `chamado`
  MODIFY `c_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `concentradores`
--
ALTER TABLE `concentradores`
  MODIFY `t_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `impressora`
--
ALTER TABLE `impressora`
  MODIFY `i_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `maquina`
--
ALTER TABLE `maquina`
  MODIFY `m_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `switch`
--
ALTER TABLE `switch`
  MODIFY `s_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
