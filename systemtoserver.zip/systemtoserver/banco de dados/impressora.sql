-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 06-Jun-2017 às 00:49
-- Versão do servidor: 10.1.21-MariaDB
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `systemtoserver`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `impressora`
--

CREATE TABLE `impressora` (
  `i_id` int(10) UNSIGNED NOT NULL,
  `i_nome` varchar(45) DEFAULT NULL,
  `i_ip` varchar(45) DEFAULT NULL,
  `i_usuario` varchar(45) DEFAULT NULL,
  `i_local` varchar(45) DEFAULT NULL,
  `i_registro` varchar(45) DEFAULT NULL,
  `i_senha` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `impressora`
--

INSERT INTO `impressora` (`i_id`, `i_nome`, `i_ip`, `i_usuario`, `i_local`, `i_registro`, `i_senha`) VALUES
(3, 'Okidata 491', '192.168.7.200', 'Administrator', 'divisão pessoal', '1508123i874', 'aaaaaa'),
(4, 'hp3136', 'Local', 'administrador', 'diretor Administrativo', '142637485', 'não possui');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `impressora`
--
ALTER TABLE `impressora`
  ADD PRIMARY KEY (`i_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `impressora`
--
ALTER TABLE `impressora`
  MODIFY `i_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
