-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 06-Jun-2017 às 00:49
-- Versão do servidor: 10.1.21-MariaDB
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `systemtoserver`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `maquina`
--

CREATE TABLE `maquina` (
  `m_id` int(10) UNSIGNED NOT NULL,
  `m_nome` varchar(45) DEFAULT NULL,
  `m_ip` varchar(45) DEFAULT NULL,
  `m_usuario` varchar(45) DEFAULT NULL,
  `m_so` varchar(45) DEFAULT NULL,
  `m_tipo` enum('x86','x64','') DEFAULT NULL,
  `m_senha` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `maquina`
--

INSERT INTO `maquina` (`m_id`, `m_nome`, `m_ip`, `m_usuario`, `m_so`, `m_tipo`, `m_senha`) VALUES
(1, 'webcmam', '10.206.160.90', 'cmam', 'linux', 'x86', 'cmam@!'),
(2, 'PIN WEB', '192.168.7.126', 'root', 'SUSE', 'x64', '123456'),
(3, 'roger', '192.168.7.10', 'administrador', 'windows 7', 'x86', '12qwaszx');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `maquina`
--
ALTER TABLE `maquina`
  ADD PRIMARY KEY (`m_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `maquina`
--
ALTER TABLE `maquina`
  MODIFY `m_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
