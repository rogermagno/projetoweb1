-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 06-Jun-2017 às 00:49
-- Versão do servidor: 10.1.21-MariaDB
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `systemtoserver`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `chamado`
--

CREATE TABLE `chamado` (
  `c_id` int(10) UNSIGNED NOT NULL,
  `c_nome` varchar(45) DEFAULT NULL,
  `c_telefone` varchar(45) DEFAULT NULL,
  `c_local` varchar(45) DEFAULT NULL,
  `c_status` varchar(45) DEFAULT NULL,
  `c_obs` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `chamado`
--

INSERT INTO `chamado` (`c_id`, `c_nome`, `c_telefone`, `c_local`, `c_status`, `c_obs`) VALUES
(3, 'Flavia', '24182435', 'divisão de pessoal', 'Aberto', 'troca de teclado'),
(4, 'Mariana', '28781122', 'divisao de estatistica', 'Aberto', 'solicita troca de mouse'),
(5, 'roger', '28981234', 'CPD', 'fechado', 'substituição de switch'),
(6, 'giulia', '23411234', 'RH', 'Aberto', 'Sistema de cadastro não funciona'),
(7, 'ana clara', '23459876', 'divisão de telemática', 'Fechado', 'problema com rede'),
(8, 'marcia', '25663342', 'call center', 'Fechado', 'configuração de impressora'),
(9, 'lyssandra', '25768798', 'recepção', 'fechado', 'Sistema de cadastro não funciona'),
(10, 'maicon', '23454356', 'administrativo', 'fechado', 'troca de mouse'),
(11, 'aline', '23459876', 'laboratório c', 'Aberto', 'Maquina 5, não liga'),
(12, 'roberta', '134555666', 'fgfgfgg', 'aberto', 'gdgdgdgdg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chamado`
--
ALTER TABLE `chamado`
  ADD PRIMARY KEY (`c_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chamado`
--
ALTER TABLE `chamado`
  MODIFY `c_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
