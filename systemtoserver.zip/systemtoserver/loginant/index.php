<?php
	session_start();
?>
<?php
	function __autoload($class_name){
		require_once 'classes/' . $class_name . '.php';
		require_once 'classes/config.php';
      //  require_once 'classes/conn.php';
        // require_once 'classes/conexao.php';

	}
?>

<!DOCTYPE HTML>
<html land="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1" />
   <title>login do sistema</title>
  <meta name="description" content="systemtoserver" />
  <meta name="robots" content="index, follow" />
  <meta charset="utf-8"/>
      <meta charset="utf-8"/>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen">
<link href="form_css/css.css" rel="stylesheet" media="screen">


   <link rel="stylesheet" href="css/bootstrap.css" />
  <link rel="stylesheet" />
  <!--[if lt IE 9]>
      <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
   <![endif]-->
</head>
<body>
<div class="wrapper">
    <form class="form-signin">       
    </span> <h2 class="form-signin-heading">Área Restrita</h2>
     <hr />
      <input type="text" class="form-control" name="email" id="email" placeholder="E-mail" required="required" />
      </br>
      <input type="password" class="form-control" name="senha" id="senha" placeholder="Senha" required="required"/>      
 		</br>
      <button class="btn btn-lg btn-primary btn-block" type="submit" name="logar" value = "logar">Acessar</button> 
       <button class="btn btn-lg btn-primary btn-block" type="sair" name="sair" value = "sair"href="sair.php">Sair</button>  
    </form>
  </div>

			<?php 
    $servidor = "localhost";
	$usuario = "root";
	$senha = "1234";
	$dbname = "systemtoserver";

     if(isset($_REQUEST['logar'])){

    $email = $_REQUEST['email'];
    $senha = $_REQUEST['senha'];

//$sql = "SELECT * FROM usuarios WHERE email = '$email' AND senha = '$senha' ";
$sql = "SELECT * FROM usuarios WHERE email = '$email' AND senha = '$senha' ";

    
        //Criar a conexao
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
	//$qtda = mysql_num_rows($query);

    
	if(!$conn){
		/*die*/ echo ("Falha na conexao: " . mysqli_connect_error());
	}else{
		echo "Conexao realizada com sucesso";
        echo "<script>location.href='http://127.0.0.1/systemtoserver/'</script>";
        
	}	

}

 
		?>	

		

	
		
	</div>

<script src="js/jQuery.js"></script>
<script src="js/bootstrap.js"></script>
</body>
</html>