<?php
$conn = mysql_connect('localhost','root','1234') or die (mysql_error());
$banco = mysql_select_db('systemtoserver') or die (mysql_error());

?>
