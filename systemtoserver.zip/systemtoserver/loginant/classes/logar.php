<?php

if(isset($_REQUEST['logar'])){


$email = $_REQUEST['email'];
$senha = $_REQUEST['senha'];

$sql = "SELECT * FROM usuarios WHERE nome = '$nome' AND senha = '$senha' ";
$query = mysql_query($sql) or die (mysql_error());
$qtda = mysql_num_rows($query);

if ($qtda == 0){
    echo 'Erro ao logar';
}
}


?>
