<?php include 'classes/conn.php'; ?>
<!DOCTYPE HTML>
<html>
   <head>
    <meta charset="utf-8"/>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen">
<link href="form_css/css.css" rel="stylesheet" media="screen">
<title>login</title>

</head>
<body>
 <hr />
<div class="container">
     
        
       <form action="login.php" method="post" name="login" id="login" class="form-signin">

<div class="wrapper">
    <form class="form-signin">       
    </span> <h2 class="form-signin-heading">Login</h2>
     <hr />
      <input type="text" class="form-control" name="nome" id="nome" placeholder="Usuário" required="required" />
      </br>
      <input type="password" class="form-control" name="senha" id="senha" placeholder="Senha" required="required"/>      
 </br>
      <button class="btn btn-lg btn-primary btn-block" type="submit" name="logar">Acessar</button>   
    </form>
  </div>
      <?php  include 'classes/logar.php'; ?>
      </form>

      
    </div></div>

      


  

</body>
</html>

<script src="js/jQuery.js"></script>
<script src="js/bootstrap.js"></script>
</body>
</html>