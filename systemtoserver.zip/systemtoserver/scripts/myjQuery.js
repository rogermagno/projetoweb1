/*! jQuery v1.8.3 jquery.com | jquery.org/license */
$(document).ready(function()){
$("div.container").on("click", "#listar", function()){
    $('#tabela').empty();//
    $ajax({

        
    })
}



}