<?php

if (!GlobalConfig::$APP_ROOT) GlobalConfig::$APP_ROOT = realpath("./");


if (ini_get('asp_tags')) 
	die('<h3>Server Configuration Problem: asp_tags is enabled, but is not compatible with Savant.</h3>'
	. '<p>You can disable asp_tags in .htaccess, php.ini or generate your app with another template engine such as Smarty.</p>');


set_include_path(
		GlobalConfig::$APP_ROOT . '/libs/' . PATH_SEPARATOR .
		GlobalConfig::$APP_ROOT . '/../phreeze/libs' . PATH_SEPARATOR .
		GlobalConfig::$APP_ROOT . '/vendor/phreeze/phreeze/libs/' . PATH_SEPARATOR .
		get_include_path()
);


require_once "App/ExampleUser.php";


require_once 'verysimple/Phreeze/SavantRenderEngine.php';
GlobalConfig::$TEMPLATE_ENGINE = 'SavantRenderEngine';
GlobalConfig::$TEMPLATE_PATH = GlobalConfig::$APP_ROOT . '/templates/';


GlobalConfig::$ROUTE_MAP = array(

	// default controller when no route specified
	'GET:' => array('route' => 'Default.Home'),
		
	// example authentication routes
	'GET:loginform' => array('route' => 'SecureExample.LoginForm'),
	'POST:login' => array('route' => 'SecureExample.Login'),
	'GET:secureuser' => array('route' => 'SecureExample.UserPage'),
	'GET:secureadmin' => array('route' => 'SecureExample.AdminPage'),
	'GET:logout' => array('route' => 'SecureExample.Logout'),
		
	// Chamado
	'GET:chamados' => array('route' => 'Chamado.ListView'),
	'GET:chamado/(:num)' => array('route' => 'Chamado.SingleView', 'params' => array('id' => 1)),
	'GET:api/chamados' => array('route' => 'Chamado.Query'),
	'POST:api/chamado' => array('route' => 'Chamado.Create'),
	'GET:api/chamado/(:num)' => array('route' => 'Chamado.Read', 'params' => array('id' => 2)),
	'PUT:api/chamado/(:num)' => array('route' => 'Chamado.Update', 'params' => array('id' => 2)),
	'DELETE:api/chamado/(:num)' => array('route' => 'Chamado.Delete', 'params' => array('id' => 2)),
		
	// Concentradores
	'GET:concentradoreses' => array('route' => 'Concentradores.ListView'),
	'GET:concentradores/(:num)' => array('route' => 'Concentradores.SingleView', 'params' => array('id' => 1)),
	'GET:api/concentradoreses' => array('route' => 'Concentradores.Query'),
	'POST:api/concentradores' => array('route' => 'Concentradores.Create'),
	'GET:api/concentradores/(:num)' => array('route' => 'Concentradores.Read', 'params' => array('id' => 2)),
	'PUT:api/concentradores/(:num)' => array('route' => 'Concentradores.Update', 'params' => array('id' => 2)),
	'DELETE:api/concentradores/(:num)' => array('route' => 'Concentradores.Delete', 'params' => array('id' => 2)),
		
	// Impressora
	'GET:impressoras' => array('route' => 'Impressora.ListView'),
	'GET:impressora/(:num)' => array('route' => 'Impressora.SingleView', 'params' => array('id' => 1)),
	'GET:api/impressoras' => array('route' => 'Impressora.Query'),
	'POST:api/impressora' => array('route' => 'Impressora.Create'),
	'GET:api/impressora/(:num)' => array('route' => 'Impressora.Read', 'params' => array('id' => 2)),
	'PUT:api/impressora/(:num)' => array('route' => 'Impressora.Update', 'params' => array('id' => 2)),
	'DELETE:api/impressora/(:num)' => array('route' => 'Impressora.Delete', 'params' => array('id' => 2)),
		
	// Maquina
	'GET:maquinas' => array('route' => 'Maquina.ListView'),
	'GET:maquina/(:num)' => array('route' => 'Maquina.SingleView', 'params' => array('id' => 1)),
	'GET:api/maquinas' => array('route' => 'Maquina.Query'),
	'POST:api/maquina' => array('route' => 'Maquina.Create'),
	'GET:api/maquina/(:num)' => array('route' => 'Maquina.Read', 'params' => array('id' => 2)),
	'PUT:api/maquina/(:num)' => array('route' => 'Maquina.Update', 'params' => array('id' => 2)),
	'DELETE:api/maquina/(:num)' => array('route' => 'Maquina.Delete', 'params' => array('id' => 2)),
		
	// Servidor
	'GET:servidors' => array('route' => 'Servidor.ListView'),
	'GET:servidor/(:any)' => array('route' => 'Servidor.SingleView', 'params' => array('id' => 1)),
	'GET:api/servidors' => array('route' => 'Servidor.Query'),
	'POST:api/servidor' => array('route' => 'Servidor.Create'),
	'GET:api/servidor/(:any)' => array('route' => 'Servidor.Read', 'params' => array('id' => 2)),
	'PUT:api/servidor/(:any)' => array('route' => 'Servidor.Update', 'params' => array('id' => 2)),
	'DELETE:api/servidor/(:any)' => array('route' => 'Servidor.Delete', 'params' => array('id' => 2)),
		
	// Switch
	'GET:switches' => array('route' => 'Switch.ListView'),
	'GET:switch/(:num)' => array('route' => 'Switch.SingleView', 'params' => array('id' => 1)),
	'GET:api/switches' => array('route' => 'Switch.Query'),
	'POST:api/switch' => array('route' => 'Switch.Create'),
	'GET:api/switch/(:num)' => array('route' => 'Switch.Read', 'params' => array('id' => 2)),
	'PUT:api/switch/(:num)' => array('route' => 'Switch.Update', 'params' => array('id' => 2)),
	'DELETE:api/switch/(:num)' => array('route' => 'Switch.Delete', 'params' => array('id' => 2)),

	// catch any broken API urls
	'GET:api/(:any)' => array('route' => 'Default.ErrorApi404'),
	'PUT:api/(:any)' => array('route' => 'Default.ErrorApi404'),
	'POST:api/(:any)' => array('route' => 'Default.ErrorApi404'),
	'DELETE:api/(:any)' => array('route' => 'Default.ErrorApi404')
);


?>